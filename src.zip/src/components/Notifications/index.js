// src/components/Notifications/index.js
export { default as NotificationDropdown } from './NotificationDropdown';
export { 
  NotificationProvider, 
  useNotifications, 
  NOTIFICATION_TYPES 
} from '../../contexts/NotificationContext';